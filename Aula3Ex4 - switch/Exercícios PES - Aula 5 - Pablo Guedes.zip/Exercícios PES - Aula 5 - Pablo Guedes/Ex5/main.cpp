#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    int valor;
    cout << "Digite o valor: ";
    cin >> valor;
    if(valor >= 0){
        cout << "N�mero positivo!";
    }
    else if(valor < 0){
        cout << "N�mero negativo!";
    }
    return 0;
}
