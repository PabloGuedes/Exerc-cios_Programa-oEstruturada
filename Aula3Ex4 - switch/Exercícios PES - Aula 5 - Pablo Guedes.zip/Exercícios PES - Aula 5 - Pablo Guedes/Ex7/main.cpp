#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    int codigo, quantidade;
    float valor;
    cout << "Digite 100 para Cachorro Quente!" << endl;
    cout << "Digite 101 para Bauru Simples!" << endl;
    cout << "Digite 102 para Bauru com Ovo!" << endl;
    cout << "Digite 103 para Hamb�rguer!" << endl;
    cout << "Digite 104 para Cheeseburguer!" << endl;
    cout << "Digite 105 para Refrigerante Lata!" << endl;
    cout << "Digite 106 para �gua!" << endl;
    cout << endl << "Informe o c�digo: ";
    cin >> codigo;
    cout << "Digite a quantidade do produto: ";
    cin >> quantidade;

    switch(codigo){
        case 100:
            cout << "Cachorro Quente: 9,20 reais." << endl;
            valor = (9.20 * quantidade);
        break;
        case 101:
            cout << "Bauru Simples: 12,00 reais." << endl;
            valor = (12.00 * quantidade);
        break;
        case 102:
            cout << "Bauru com Ovo: 13,00 reais." << endl;
            valor = (13.00 * quantidade);
        break;
        case 103:
            cout << "Hamb�rguer: 10,00 reais." << endl;
            valor = (10.00 * quantidade);
        break;
        case 104:
            cout << "Cheeseburguer: 12,00 reais." << endl;
            valor = (12.00 * quantidade);
        break;
        case 105:
            cout << "Refrigerante Lata: 5,00 reais." << endl;
            valor = (5.00 * quantidade);
        break;
        case 106:
            cout << "�gua: 3,00 reais." << endl;
            valor = (3.00 * quantidade);
        break;
        default:
            cout << "Op��o inv�lida!";
    }

    cout << "O valor a ser pago � de: R$" << valor;

    return 0;
}
