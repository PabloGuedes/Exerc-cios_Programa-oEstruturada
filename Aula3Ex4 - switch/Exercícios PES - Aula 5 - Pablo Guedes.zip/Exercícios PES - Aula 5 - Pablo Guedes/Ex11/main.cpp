#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    int numero, negativos = 0;
    for(int contador = 0; contador < 3; contador++){
        cout << "Digite um n�mero: ";
        cin >> numero;


        if(numero < 0){
            negativos++;
        }
    }
    cout << endl << "Foram digitados " << negativos << " n�meros negativos.";
    return 0;
}
