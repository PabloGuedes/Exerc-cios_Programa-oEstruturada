#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    int numero, pares = 0, soma = 0;
    double media;

    for(int contador = 1; contador <= 20; contador++){
        cout << "Digite um n�mero: ";
        cin >> numero;
        if(numero % 2 == 0){
            pares++;
            soma = soma + numero;
            media = soma / pares;
        }
    }

    cout << "A m�dia dos n�meros pares � igual a: " << media;

    return 0;
}
