#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    double altura, pesoIdeal;
    char sexo;

    cout << "Digite a altura: ";
    cin >> altura;
    cout << endl << "Digite o sexo - M ou F: ";
    cin >> sexo;

    cout << endl << "A altura �: " << altura << endl;

    switch(sexo){
        case 'M':
            pesoIdeal = (72.7 * altura) - 58;
            cout << "O sexo � Masculino." << endl;
            cout << "O peso ideal �: " << pesoIdeal;
        break;
        case 'F':
            pesoIdeal = (62.1 * altura) - 44.7;
            cout << "O sexo � Feminino." << endl;
            cout << "O peso ideal �: " << pesoIdeal;
        break;
        default:
            cout << "Sexo inv�lido!";
    }

    return 0;
}
