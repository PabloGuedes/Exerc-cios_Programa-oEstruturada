#include <iostream>
#include <locale>
#include <cmath>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    float raio, area, perimetro;
    cout << "Informe o raio do c�rculo: ";
    cin >> raio;
    area = 3.14 * pow(raio, 2);
    perimetro = (2 * 3.14 * raio);
    cout << "A �rea deste c�rculo �: " << area << endl;
    cout << "O per�metro deste c�crulo �: " << perimetro;
    return 0;
}
