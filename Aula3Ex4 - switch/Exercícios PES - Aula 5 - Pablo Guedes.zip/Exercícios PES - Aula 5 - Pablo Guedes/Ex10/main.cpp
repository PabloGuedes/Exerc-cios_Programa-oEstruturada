#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    int matricula;
    double n1, n2, n3, media;
    cout << "Digite o n�mero da matr�cula do aluno: ";
    cin >> matricula;
    cout << "Digite a nota 1: ";
    cin >> n1;
    cout << "Digite a nota 2: ";
    cin >> n2;
    cout << "Digite a nota 3: ";
    cin >> n3;

    media = (n1 + n2 * 2 + n3 * 3) / 6;

    if(media >= 9.0){
       cout << endl << "N�mero da matr�cula do aluno: " << matricula << endl;
       cout << "Nota 1 do aluno: " << n1 << endl;
       cout << "Nota 2 do aluno: " << n2 << endl;
       cout << "Nota 3 do aluno: " << n3 << endl;
       cout << "A m�dia de aproveitamento do aluno �: " << media << endl;
       cout << "O conceito � A." << endl;
       cout << "Aluno APROVADO!" << endl;
    }
    else if((media >= 7.5) && (media < 9.0)){
       cout << endl << "N�mero da matr�cula do aluno: " << matricula << endl;
       cout << "Nota 1 do aluno: " << n1 << endl;
       cout << "Nota 2 do aluno: " << n2 << endl;
       cout << "Nota 3 do aluno: " << n3 << endl;
       cout << "A m�dia de aproveitamento do aluno �: " << media << endl;
       cout << "O conceito � B." << endl;
       cout << "Aluno APROVADO!" << endl;
    }
    else if((media >= 6.0) && (media < 7.5)){
       cout << endl << "N�mero da matr�cula do aluno: " << matricula << endl;
       cout << "Nota 1 do aluno: " << n1 << endl;
       cout << "Nota 2 do aluno: " << n2 << endl;
       cout << "Nota 3 do aluno: " << n3 << endl;
       cout << "A m�dia de aproveitamento do aluno �: " << media << endl;
       cout << "O conceito � C." << endl;
       cout << "Aluno APROVADO!" << endl;
    }
    else if((media >= 4.0) && (media < 6.0)){
       cout << endl << "N�mero da matr�cula do aluno: " << matricula << endl;
       cout << "Nota 1 do aluno: " << n1 << endl;
       cout << "Nota 2 do aluno: " << n2 << endl;
       cout << "Nota 3 do aluno: " << n3 << endl;
       cout << "A m�dia de aproveitamento do aluno �: " << media << endl;
       cout << "O conceito � D." << endl;
       cout << "Aluno REPROVADO!" << endl;
    }
    else if(media < 4.0){
       cout << endl << "N�mero da matr�cula do aluno: " << matricula << endl;
       cout << "Nota 1 do aluno: " << n1 << endl;
       cout << "Nota 2 do aluno: " << n2 << endl;
       cout << "Nota 3 do aluno: " << n3 << endl;
       cout << "A m�dia de aproveitamento do aluno �: " << media << endl;
       cout << "O conceito � E." << endl;
       cout << "Aluno REPROVADO!" << endl;
    }
    return 0;
}
