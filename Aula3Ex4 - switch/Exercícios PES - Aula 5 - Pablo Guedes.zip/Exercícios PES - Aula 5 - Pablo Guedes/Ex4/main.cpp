#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    char nome[20];
    float valor, desconto;
    cout << "Informe um nome do Produto: ";
    cin >> nome;
    cout << "Informe o valor do Produto: ";
    cin >> valor;
    desconto = (valor * 0.13);
    cout << endl << "Nome do produto: " << nome << endl;
    cout << "Valor original: " << valor << endl;
    cout << "Valor do desconto: " << desconto << endl;
    cout << "Valor do produto ap�s o desconto: " << valor - desconto;
    return 0;
}
