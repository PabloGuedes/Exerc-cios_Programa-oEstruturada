#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    char nome[20];
    cout << "Digite seu nome: ";
    cin >> nome;
    cout << endl << "Meu nome � " << nome << "." << endl;
    cout << "Sou do curso de Sistemas de Informa��o." << endl;
    cout << "Estou no primeiro ano." << endl;
    cout << "Gosto de programa��o!!!" << endl;
    return 0;
}
