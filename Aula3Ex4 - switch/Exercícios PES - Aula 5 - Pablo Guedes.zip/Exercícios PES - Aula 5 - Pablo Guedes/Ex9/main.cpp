#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");
    int numero;
    cout << "Digite um n�mero positivo e inteiro: ";
    cin >> numero;
    if(numero%2==0){
        cout << "O n�mero � par.";
    }
    else{
        cout << "O n�mero � �mpar.";
    }
    return 0;
}
