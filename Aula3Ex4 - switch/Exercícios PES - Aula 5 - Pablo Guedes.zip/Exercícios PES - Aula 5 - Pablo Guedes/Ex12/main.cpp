#include <iostream>
#include <locale>

using namespace std;

int main()
{
    setlocale(LC_ALL, "Portuguese");

    int numero, soma = 0, media;

    for(int contador = 0; contador < 20; contador++){
        cout << "Informe um n�mero inteiro e positivo: ";
        cin >> numero;
        soma+=numero;
    }
    media = soma / 20;
    cout << "A m�dia aritm�tica �: " << media;
}
